/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Codes;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

/**
 *
 * @author sirfi
 */
public class FonctionsMessages {
    
     public Connexion  _connexion = new Connexion();
     
      public void BoxClePrivees (JComboBox<String>  bx){
        Statement stmt;
         ResultSet Rs;
      try{
            Connection con = _connexion.connex();
             stmt = con.createStatement();
             
            String sql="SELECT * FROM utilisateur";
             Rs = stmt.executeQuery(sql);
      
            while(Rs.next()){
             String cat = Rs.getString("email");
             bx.addItem(cat);
            }
            con.close();
        }
        catch(Exception e){JOptionPane.showMessageDialog(null, e);
        }
    
     }
      
      public void BoxClePub(String id, JComboBox<String>  bx ){
           try{
          Connection con = _connexion.connex();
         String sql="SELECT * FROM cle_pub WHERE id_auteur = '"+id+"' OR id_destinatairee ='"+id+"'";
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
           
            while(rs.next()){
            String cat = rs.getString("nomcle");
            bx.addItem(cat);
         //   con.close();
            // jTextArea1.setText(rs.getString("description"));
            }
             bx.addItem(" ");
        }
        catch(Exception e){JOptionPane.showMessageDialog(null, e);
        }
      }
      
      public ClePublic ComboBox1MouseClicked(String stg, String id){
          Statement stmt;
          ResultSet Rs;
           ClePublic   cp = new ClePublic(null,null, null) ;
        //  BigInteger[] res = new BigInteger
         try{
             Connection con = _connexion.connex();
              stmt = con.createStatement();
              String requette  = "SELECT * FROM cle_pub WHERE nomcle = '"+stg+"' AND id_auteur ='"+id+"'" ;
              Rs = stmt.executeQuery(requette);
          while(Rs.next()){
           BigInteger p = new BigInteger(Rs.getString("valeurp"));
           BigInteger g = new BigInteger(Rs.getString("valeurg"));
           BigInteger  h = new BigInteger(Rs.getString("valeurh"));
           cp = new ClePublic(p,g,h);
            stmt.close();
        //    con.close();
          }
                  }
        catch(Exception ex){
        
        }
         return cp;
      }
}
