/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Codes;

import static Codes.ElGamal.Dechiffrement;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author sirfi
 */
public class Dechiffrer {
     public static Connexion  _connexion = new Connexion();
    static ClePrivee cpv;
    static  BigInteger c1;
    static  BigInteger c2;
   static  BigInteger p;
   static  BigInteger a;
     
     
     public static void dechiffrer(){
          String stg ="nuit" ;//String.valueOf( jList1.getSelectedValue());
       // System.out.println(stg);
      //  ArrayList Alist1 =  new ArrayList();
        
        ;
        Statement stmt;
        ResultSet Rs;
        
        try{
             Connection con = _connexion.connex();
              stmt = con.createStatement();
              String requette  = "SELECT * FROM chiffres WHERE nom_chiffres='"+stg+"' " ;
              Rs = stmt.executeQuery(requette);
          while(Rs.next()){
       //   IdSelected = Rs.getInt(1);
       
        c1 = new BigInteger (Rs.getString("chiffre_1"));
        c2 = new BigInteger (Rs.getString("chiffre_2"));
        System.out.println(c1);
        System.out.println(c2);
//          ch1.setText(new String (c1.toByteArray()));
//          ch2.setText(new String (c2.toByteArray()));
          
          
          }
//       
                  }
        catch(Exception ex){
        
        }
        
          String stg2 = "lanuit";//String.valueOf( jComboBox1.getSelectedItem());
        try{
         String sql="SELECT * FROM cleprivee WHERE nomcle ='"+stg2+"'";
            PreparedStatement pst = _connexion.conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
           
            while(rs.next()){
//            String cat = rs.getString("nomcle");
//            jComboBox1.addItem(cat);
            // jTextArea1.setText(rs.getString("description"));
            p = new BigInteger(rs.getString("valeurp"));
            a = new BigInteger(rs.getString("valeura"));
            }
           //  System.out.println(p);
        }
        catch(Exception e){JOptionPane.showMessageDialog(null, e);
        }       
        cpv =new ClePrivee(p, a);
     //   System.out.println(p);
          BigInteger[] st = {c1 , c2};
//         st[0]= c1;
//         st[1] = c2;
        System.out.println(cpv.p);
        System.out.println(cpv.x);
String dechiffre = Dechiffrement(st, cpv);
 System.out.println(dechiffre);
     }
      
}
