/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Codes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author sirfi
 */
public class FonctionsMessRecus {
    
     public int IdSelected;
     public Connexion _connexion;
     
       public FonctionsMessRecus() {
        this._connexion = new Connexion();
    }
       
    public void Expediteur(JTextField txtfld, String obj){
         String id_auteur = null;
         Statement stmt;
         ResultSet Rs;
         
      try{
            Connection con = _connexion.connex();
             stmt = con.createStatement();
            String sql="SELECT * FROM chiffres WHERE nom_chiffres ='"+obj+"'";
             Rs = stmt.executeQuery(sql);
      
            while(Rs.next()){
             id_auteur = Rs.getString("id_auteur");
           
            }
            con.close();
        }
        catch(Exception e){JOptionPane.showMessageDialog(null, e);
        }
      
       try{
            Connection con = _connexion.connex();
             stmt = con.createStatement();
            String sql="SELECT * FROM utilisateur WHERE id ='"+Integer.parseInt(id_auteur)+"'";
             Rs = stmt.executeQuery(sql);
      
            while(Rs.next()){
            txtfld.setText( Rs.getString("nom")+" "+Rs.getString("prenom")+" -- "+Rs.getString("email")); 
           
            }
            con.close();
        }
        catch(Exception e){JOptionPane.showMessageDialog(null, e);
        } 
    }
    
     public void Date(JTextField txtfld, String obj){
         String id_auteur = null;
         Statement stmt;
         ResultSet Rs;
         txtfld.setText("");
         try{
            Connection con = _connexion.connex();
             stmt = con.createStatement();
            String sql="SELECT * FROM messages WHERE objet ='"+obj+"'";
             Rs = stmt.executeQuery(sql);
      
            while(Rs.next()){
             txtfld.setText(Rs.getString("date"));
           
            }
            con.close();
        }
        catch(Exception e){JOptionPane.showMessageDialog(null, e);
        }
     }
    
     public void Suppression(JButton btn, String obj){
//            Statement stmt;
//            ResultSet Rs;
            int YesOrNo = JOptionPane.showInternalConfirmDialog(btn.getParent(), "ETES VOUS SURS DE VOULOIR SUPPRIMER CET MESSAGE DEFINITIVEMENT?");
            //int YesOrNo = JOptionPane.showConfirmDialog(null, "EST VOUS SUR DE VOUR ANNULER CETTE VENTE","ANNULER VENTE", JOptionPane.YES_NO_OPTION);
            if (YesOrNo ==0){
                try{
                    Connection con = _connexion.connex();
                    //
                    PreparedStatement st = con.prepareStatement("DELETE FROM chiffres WHERE nom_chiffres= '" +obj+ "';");
                    st.executeUpdate();
                    st = con.prepareStatement("DELETE FROM messages WHERE objet= '" +obj+ "';");
                    st.executeUpdate();
                    st.close();
                    // rafraichir();
                }
                catch(Exception ex){

                }
            }
}
}