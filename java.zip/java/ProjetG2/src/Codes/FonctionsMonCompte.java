/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Codes;

import javax.swing.JTextField;

/**
 *
 * @author sirfi
 */
public class FonctionsMonCompte {
    
     public void SetEnableFalse(JTextField t1, JTextField t2, JTextField t3, JTextField t4, JTextField t5){
            t1.setEnabled(false);
            t2.setEnabled(false);
            t3.setEnabled(false);
            t4.setEnabled(false);
            t5.setEnabled(false); 
    }
     
      public void SetEnableTrue(JTextField t1, JTextField t2, JTextField t3, JTextField t4, JTextField t5){
            t1.setEnabled(true);
            t2.setEnabled(true);
            t3.setEnabled(true);
            t4.setEnabled(true);
            t5.setEnabled(true);
           
        
    }
    
}
