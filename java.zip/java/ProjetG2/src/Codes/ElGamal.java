/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Codes;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Scanner;

/**
 *
 * @author sirfi
 */
public class ElGamal {
 // public BigInteger p,g,h,a,d;
 
    /**
     * @param args the command line arguments
     */
//    public static void main(String[] args) {
//        // TODO code application logic here
//          ClePublic cp;
//          ClePrivee cpv;
//         Scanner s = new Scanner(System.in);
//         System.out.println("Entrer le message à chiffrer");
//         String message = s.nextLine();
//         
//          System.out.println("Entrer la taille de la cle");
//          int nbb = s.nextInt() ;
//          
//           BigInteger[] k =genKey(nbb);
//          cp=new ClePublic(k[0],k[1],k[2]);
//          cpv =new ClePrivee(k[0],k[3]);
//          
//           BigInteger[] st= Chiffrement(message, cp);
//           System.out.println("chiffre 1: "+ st[0]);
//           System.out.println("chiffre 2: "+ st[1]);
//           
//           String dechiffre = Dechiffrement(st, cpv);
//           System.out.println("Le chiffre est: "+dechiffre);
//          
//    }
    
     public static BigInteger[] genKey(int nbb) {
         SecureRandom sr = new SecureRandom();
         BigInteger p = BigInteger.probablePrime(nbb, sr);
         BigInteger   d = p.subtract(BigInteger.ONE);
         BigInteger g;
         
         do {
             g= new BigInteger(64,sr);
         }while(g.modPow(d, p).intValue()!=1);
       BigInteger  a= new BigInteger(512, sr);
       BigInteger  h=g.modPow(a, p);
         
        BigInteger[] key = new BigInteger[4];
        key[0]=p;
        key[1]=h;
        key[2]=g;
        key[3]=a;
        
        return key;
       // cp=new ClePublic(p,h,g);
       // cpv =new ClePrivee(p,a);
        
         }
     
     
     public static BigInteger[] Chiffrement(String mgs, ClePublic _cp ){
         SecureRandom sr = new SecureRandom();
         BigInteger m = new BigInteger(mgs.getBytes());
         BigInteger k = new BigInteger(32, sr);
         BigInteger c1 = _cp.getG().modPow(k, _cp.getP());
         BigInteger c2 = m.multiply(_cp.getH().modPow(k, _cp.getP())).mod(_cp.getP());
        // System.out.println("chiffre 1: "+ new String(c1.toByteArray()));
        // System.out.println("chiffre 2: "+ new String(c2.toByteArray()));
         BigInteger[] res = new BigInteger[2];
         res[0]=c1;
         res[1]=c2;
         return res;
         
     }
     
    public static String Dechiffrement(BigInteger[]msg, ClePrivee _cpv ){
         BigInteger c1 = msg[0];
         BigInteger c2 = msg[1];
         BigInteger d = _cpv.getP().subtract(BigInteger.ONE);
         BigInteger m1 = c1.modPow(d.subtract(_cpv.getX()),_cpv.getP()).multiply(c2).mod(_cpv.getP());
         
         return new String(m1.toByteArray());
       
    
    } 
    
}
