/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Codes;

import java.awt.List;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author sirfi
 */

public class FonctionsMesCles {
     public int IdSelected;
     public Connexion _connexion;
      DefaultTableModel model ;

    public FonctionsMesCles() {
        this._connexion = new Connexion();
    }
     
     public void BoxClePrivees (JComboBox<String>  bx){
        Statement stmt;
         ResultSet Rs;
      try{
            Connection con = _connexion.connex();
             stmt = con.createStatement();
             
            String sql="SELECT * FROM utilisateur";
             Rs = stmt.executeQuery(sql);
      
            while(Rs.next()){
             String cat = Rs.getString("email");
             bx.addItem(cat);
            }
            con.close();
        }
        catch(Exception e){JOptionPane.showMessageDialog(null, e);
        }
    
     }
     
      public void RemplirTableClePub(JTable table, String id){
      
           model = new DefaultTableModel();
       model.addColumn("ID");
       model.addColumn("NOM CLE");
       model.addColumn("VALEUR P");
       model.addColumn("VALEUR G");
       model.addColumn("VALEUR H");
    
        Statement stmt;
        ResultSet Rs;
        
         try{
             Connection con = _connexion.connex();
              stmt = con.createStatement();
              String requette  = "SELECT * FROM cle_pub WHERE id_auteur='"+id+"' OR id_destinatairee = '"+id+"'" ;
              Rs = stmt.executeQuery(requette);
                
          while(Rs.next()){
          
          model.addRow(new Object[]{Rs.getString(1),Rs.getString(2),Rs.getString(3),Rs.getString(4),Rs.getString(5)});
          }
        
          table.setModel(model);
          con.close();
                  }
        catch(Exception ex){
        
        }
      
      }
       public void RemplirTableClePriv(JTable table, String id){
       
       model = new DefaultTableModel();
       model.addColumn("ID");
       model.addColumn("NOM CLE");
       model.addColumn("VALEUR P");
       model.addColumn("VALEUR A");
       
    
        Statement stmt;
        ResultSet Rs;
        
        try{
             Connection con = _connexion.connex();
              stmt = con.createStatement();
              String requette  = "SELECT * FROM cleprivee WHERE id_auteur='"+id+"' " ;
              Rs = stmt.executeQuery(requette);
                
          while(Rs.next()){
           model.addRow(new Object[]{Rs.getString(1),Rs.getString(2),Rs.getString(3),Rs.getString(4)});
          }
        
          table.setModel(model);
          con.close();
                  }
        catch(Exception ex){
        
        }
       }
       
     public int RequetteId (String s){
     Statement st = null;
      String stg = s;//= (String) jComboBox2.getSelectedItem();
      Connection con = _connexion.connex();
      int idd = 0 ;
         try{
         String sql="SELECT * FROM utilisateur WHERE email ='"+stg+"'";
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
           
            while(rs.next()){
            idd = rs.getInt("id");
            
            }
       
          //  con.close();
        }
        catch(Exception e){JOptionPane.showMessageDialog(null, e);
        }
     return idd;
     }
     
     public void Enregistrer(String id, int idd,  BigInteger[] k,  String nom){
         Statement st = null;
         Connection con = _connexion.connex();
          try{
                  
                   String ccccc = nom;
                   String p = String.valueOf(k[0]) ;
                   String g = String.valueOf(k[1]);
                   String h = String.valueOf(k[2]);                  
                   String a = String.valueOf(k[3]);
                    st= con.createStatement();
                    st.executeUpdate("INSERT into cleprivee(nomcle, valeurp, valeura, id_auteur) VALUES ('"+ccccc+"','"+p+"','"+a+"','"+id+"')");
                    st.executeUpdate("INSERT into cle_pub(nomcle, valeurp, valeurg, valeurh, id_auteur, id_destinatairee) VALUES ('"+ccccc+"','"+p+"','"+g+"','"+h+"','"+id+"','"+idd+"')");
                    st.close();
                    con.close();
                    //   JOptionPane.showInternalMessageDialog(this, "Clé bien enregistrée")
                     
                }
                catch(Exception e){
                    System.out.println("Echec Envoi "+e.getMessage());
                }
     }
     
     public void SupprimerClePub(JTable jtable){
         
        IdSelected = jtable.getSelectedRow();
        TableModel  tmodel =jtable.getModel();
         
            Statement stmt;
            ResultSet Rs;
            int YesOrNo = JOptionPane.showInternalConfirmDialog(jtable.getParent(), "ETES VOUS SURS DE VOULOIR SUPPRIMER CETTE CLE DEFINITIVEMENT?");
            //int YesOrNo = JOptionPane.showConfirmDialog(null, "EST VOUS SUR DE VOUR ANNULER CETTE VENTE","ANNULER VENTE", JOptionPane.YES_NO_OPTION);
            if (YesOrNo ==0){
                try{
                    Connection con = _connexion.connex();
                    //
                    PreparedStatement st = con.prepareStatement("DELETE FROM cle_pub WHERE id_cle_pub= '" +tmodel.getValueAt(IdSelected, 0)+ "';");
                    st.executeUpdate();
                    st.close();
                    // rafraichir();
                }
                catch(Exception ex){

                }
               
        }
     }
     
      public void SupprimerClePriv(JTable jtable){
         
        IdSelected = jtable.getSelectedRow();
        TableModel  tmodel =jtable.getModel();
         
            Statement stmt;
            ResultSet Rs;
            int YesOrNo = JOptionPane.showInternalConfirmDialog(jtable.getParent(), "ETES VOUS SURS DE VOULOIR SUPPRIMER CETTE CLE DEFINITIVEMENT?");
            //int YesOrNo = JOptionPane.showConfirmDialog(null, "EST VOUS SUR DE VOUR ANNULER CETTE VENTE","ANNULER VENTE", JOptionPane.YES_NO_OPTION);
            if (YesOrNo ==0){
                try{
                    Connection con = _connexion.connex();
                    //
                    PreparedStatement st = con.prepareStatement("DELETE FROM cleprivee WHERE nomcle= '" +tmodel.getValueAt(IdSelected, 1)+ "';");
                    st.executeUpdate();
                    st.close();
                    PreparedStatement stt = con.prepareStatement("DELETE FROM cle_pub WHERE nomcle= '" +tmodel.getValueAt(IdSelected, 1)+ "';");
                    stt.executeUpdate();
                    stt.close();
                
                }
                catch(Exception ex){

                }
               
        }
     }
     
}
