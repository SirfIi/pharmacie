/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Codes;

import java.math.BigInteger;

/**
 *
 * @author sirfi
 */
public class ClePublic {
    public BigInteger p;
    public BigInteger h;
    public BigInteger g;
    
    public ClePublic(BigInteger p,BigInteger h,BigInteger g){
     this.p=p;
     this.h=h;
     this.g=g;
   }

    public BigInteger getP() {
        return p;
    }
    

    public BigInteger getH() {
        return h;
    }

  
    public BigInteger getG() {
        return g;
    }
    
}
