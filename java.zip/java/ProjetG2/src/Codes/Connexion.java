/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Codes;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author sirfi
 */
public class Connexion {
    
    private static final String utilisateur = "root";
    private static final String motDePasse ="";
    private static final String conn_string = "jdbc:mysql://localhost:3306/bdg2?autoReconnect=true&useSSL=false";
    public Connection conn = null;
    public Connection connex(){
   
        try {
         conn = DriverManager.getConnection(conn_string,utilisateur,motDePasse);
         //System.out.println("Connected");
        }
        catch(Exception e){System.out.println("echec connexion a la base "+e.getMessage());
        }
        return conn;
}
}