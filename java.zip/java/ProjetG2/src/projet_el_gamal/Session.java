/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet_el_gamal;

/**
 *
 * @author sirfi
 */
public class Session {
    public static String ID ;
    public static String NOM ;
     public static String PRENOM ;
    public static String LOGIN;
    public static String EMAIL;
    
//      public Session(String ID, String NOM, String LOGIN){
//      this.ID = ID;
//      this.NOM = NOM;
//      this.LOGIN = LOGIN;
//  }
     public void setID(String id){
        ID = id;
    }
      public String getID(){
          return ID;
      }
      
       public void setNOM(String nom){
        NOM = nom;
    }
      public String getNOM(){
          return NOM;
      }
      
    public void setLogin(String login){
        LOGIN = login;
    }
      public String getLogin(){
          return LOGIN;
      }
    
       public void setEmail(String email){
        EMAIL = email;
    }
      public String getEmail(){
          return EMAIL;
      }
      
      public void setPrenom(String prenom){
        PRENOM = prenom;
    }
      public String getPrenom(){
          return PRENOM;
      }
}
