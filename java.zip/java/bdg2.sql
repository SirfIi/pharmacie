-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 04, 2019 at 03:50 PM
-- Server version: 5.7.14
-- PHP Version: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bdg2`
--

-- --------------------------------------------------------

--
-- Table structure for table `chiffres`
--

CREATE TABLE `chiffres` (
  `id` int(100) NOT NULL,
  `nom_chiffres` varchar(2048) NOT NULL,
  `chiffre_1` varchar(2048) CHARACTER SET armscii8 NOT NULL,
  `chiffre_2` varchar(2048) CHARACTER SET armscii8 NOT NULL,
  `id_auteur` varchar(100) NOT NULL,
  `id_destinatairee` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cleprivee`
--

CREATE TABLE `cleprivee` (
  `idpriv` int(11) NOT NULL,
  `nomcle` varchar(100) NOT NULL,
  `valeurp` varchar(2048) NOT NULL,
  `valeura` varchar(2048) NOT NULL,
  `id_auteur` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cle_pub`
--

CREATE TABLE `cle_pub` (
  `id_cle_pub` int(100) NOT NULL,
  `nomcle` varchar(50) NOT NULL,
  `valeurp` varchar(2048) NOT NULL,
  `valeurg` varchar(2048) NOT NULL,
  `valeurh` varchar(2048) NOT NULL,
  `id_auteur` int(100) NOT NULL,
  `id_destinatairee` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(100) NOT NULL,
  `objet` varchar(50) NOT NULL,
  `message` varchar(2048) NOT NULL,
  `date` varchar(255) NOT NULL,
  `id_exp` int(100) NOT NULL,
  `id_dest` int(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `id` int(11) NOT NULL,
  `designation_status` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id`, `designation_status`) VALUES
(1, 'Vendeur'),
(2, 'Gerant'),
(3, 'Stagiaire');

-- --------------------------------------------------------

--
-- Table structure for table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `id` int(100) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `admin` int(1) NOT NULL,
  `mdp` varchar(100) NOT NULL,
  `login` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `utilisateur`
--

INSERT INTO `utilisateur` (`id`, `nom`, `prenom`, `email`, `admin`, `mdp`, `login`) VALUES
(1, 'admin', 'admin', 'admin@gmail.com', 1, 'admin', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chiffres`
--
ALTER TABLE `chiffres`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cleprivee`
--
ALTER TABLE `cleprivee`
  ADD PRIMARY KEY (`idpriv`);

--
-- Indexes for table `cle_pub`
--
ALTER TABLE `cle_pub`
  ADD PRIMARY KEY (`id_cle_pub`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chiffres`
--
ALTER TABLE `chiffres`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;
--
-- AUTO_INCREMENT for table `cleprivee`
--
ALTER TABLE `cleprivee`
  MODIFY `idpriv` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT for table `cle_pub`
--
ALTER TABLE `cle_pub`
  MODIFY `id_cle_pub` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `status`
--
ALTER TABLE `status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
